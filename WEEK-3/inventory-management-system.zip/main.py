inventory = [('Item1', 10), ('Item2', 100), ('Item3', 0)]
for item, quantity in inventory:
    if quantity == 0:
        print(item," is out of stock.")