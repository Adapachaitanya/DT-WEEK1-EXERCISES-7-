public class ContactManagementTest {
    public static void main(String[] args) {
        ContactManagement management = new ContactManagement();

        Contact c1 = new Contact(1, "adapa", "9154873299");
        Contact c2 = new Contact(2, "kora", "9121932235");

        management.addContact(c1);
        management.addContact(c2);

        management.displayContacts();

        management.removeContact(1);
        management.displayContacts();
    }
}