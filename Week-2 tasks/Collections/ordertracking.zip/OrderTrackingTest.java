public class OrderTrackingTest {
    public static void main(String[] args) {
        OrderTracking tracking = new OrderTracking();

        tracking.addOrder(new Order(101, "samosa"));
        tracking.addOrder(new Order(102, "nuggots"));

        tracking.displayOrders();

        tracking.processOrder();
        tracking.displayOrders();
    }
}