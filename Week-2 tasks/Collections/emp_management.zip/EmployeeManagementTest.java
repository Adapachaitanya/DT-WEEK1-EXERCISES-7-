public class EmployeeManagementTest {
    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement();

        Employee emp1 = new Employee(1, "Adapa", "143 adapa St");
        Employee emp2 = new Employee(2, "Kora", "456 kora St");

        management.addEmployee(emp1);
        management.addEmployee(emp2);

        management.displayEmployees();

        management.updateEmployee(1, "789 balla St");
        management.removeEmployee(2);

        management.displayEmployees();
    }
}