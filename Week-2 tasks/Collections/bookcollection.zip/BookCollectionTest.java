public class BookCollectionTest {
    public static void main(String[] args) {
        BookCollection collection = new BookCollection();

        collection.addBook("Ignited Minds");
        collection.addBook("To Kill a Mockingbird");
        collection.addBook("Bionucleas");

        collection.displayBooks();

        collection.removeBook("To Kill a Mockingbird");
        collection.displayBooks();
    }
}